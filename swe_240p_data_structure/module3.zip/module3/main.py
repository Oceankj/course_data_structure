from .read_and_parse import read_and_parse


read_and_parse()
