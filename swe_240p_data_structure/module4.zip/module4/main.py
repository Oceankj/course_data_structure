from swe_240p_data_structure.module4.BST import BST

bst = BST()
# bst.inOrderTraversal()
# bst.postOrderTraversal()
# bst.preOrderTraversal()
bst.levelOrderTraversal()
