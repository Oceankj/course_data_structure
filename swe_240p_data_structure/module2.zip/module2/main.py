# from module2.calculator import calculator

# from module2.stack import Stack

# print(
#     calculator("1 + 2 - 3 + 4 - 5 + 6 * 2 / 3"),
#     (1 + 2 - 3 + 4 - 5 + 6 * 2 / 3),
# )
